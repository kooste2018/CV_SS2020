function [mask] = bound(mask, s)
    % Find pixel
    [rows, cols] = find(mask);
    % Calculate boundary
    k = boundary(rows, cols, s);
    a = cols(k);
    b = rows(k);
    % Create Polygon (zip rows & cols)
    poly = [a(:),b(:)].';
    poly = poly(:)';
    % Insert Polygon
    mask_bound = rgb2gray(insertShape(uint8(mask), 'Polygon', poly));
    % Fill shape
    mask = logical(imfill(mask_bound, 'holes'));
end
