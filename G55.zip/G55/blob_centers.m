function [centers, mask_1, mask_2] = blob_centers(mask, threshold)
    %% Get coordinates of white pixels
    [rows, cols] = find(mask);
    X = [rows, cols];
    
    %% Split mask into 15 cluster
    k_opt = 15;
    % kmeans cluster analysis
    [idx, C] = kmeans(X, k_opt, 'MaxIter', 70);
    
    %% Postprocess cluster: we want a maximum of two clusters
    cluster_ind = [1:size(C, 1)]';
    % Sort cluster centers x-coordinates
    C_wind = [cluster_ind, C];
    C_sort = sortrows(C_wind,3);
    C = C_sort(:, 2:end);
    cluster_ind = C_sort(:,1);
    % Since clusters are in a different order we have to change the idx
    % variable too
    new_idx = zeros(size(idx));
    for i = 1:size(cluster_ind, 1)
        new_idx(idx == cluster_ind(i)) = i;       
    end
    idx = new_idx;
    
    % Check distance between cluster centers
    % If max dist > threshold there is more than one moving object
    diff_max = -Inf;
    i_max = 0;
    for i = 1: size(C, 1)-1
        diff = C(i+1, 2) - C(i, 2);
        if diff > diff_max
            diff_max = diff;
            if diff_max > threshold
                i_max = i;
            end
        end
    end
    
    % Combine clusters into a max of two clusters
    if i_max == 0
        centers = mean(C, 1);
    else
        centers = mean(C(1:i_max, :), 1);
        centers = [centers; mean(C(i_max+1:end, :), 1)];
    end
    
    % Reassign points to new clusters
    mask_1 = zeros(size(mask));
    mask_2 = zeros(size(mask));
    if size(centers, 1) == 1
        mask_1 = mask;
    else
        idx(idx <= i_max) = 1;
        idx(idx > i_max) = 2;
        for i = 1:size(idx)
            if idx(i) == 1
                mask_1(rows(i), cols(i)) = 1;
            else
                mask_2(rows(i), cols(i)) = 1; 
            end
        end
    end
end
