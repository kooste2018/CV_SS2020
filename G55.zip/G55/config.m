%% Computer Vision Challenge 2020 config.m

%% Generall Settings
% Group number:
group_number = 55;

% Group members:
members = {'Matthias Emde', 'Andreas Loesel'};

% Email-Address (from Moodle!):
mail = {'ga63suz@tum.de', 'ga63miy@tum.de'};


%% Setup Image Reader
% Specify Scene Folder
src = "Pfad\zum\Datenset";

% Select Cameras
L = 1;
R = 2;

% Choose a start point
start = randi(1000);

% Choose the number of succseeding frames
N = 4;

ir = ImageReader(src, L, R, start, N);


%% Output Settings
% Output Path
dst = "output.avi";

% Load Virtual Background
bg = imread("Pfad\zu\Bild\Datei");

% Load Virtual Background video
% video_file = 'Pfad\zu\Video\Datei';
% bg = VideoReader(video_file);

% Select rendering mode
render_mode = "foreground";

% Store Output?
store = true;

%% Convenience Settings
close all;
beep off;
