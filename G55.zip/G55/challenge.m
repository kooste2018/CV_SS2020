%% Computer Vision Challenge 2020 challenge.m
config

%% Start timer here
tic

%% Generate Movie
loop = 0;

batch_size = 10;
video_file = matfile('video.mat', 'Writable', true);

video_buffer = zeros(batch_size, 600, 800 , 3);
video_file.video = zeros(1, 600, 800, 3);

frame_count = 0;

while loop ~= 1
    % Get next image tensors
    [left, right, loop] = ir.next();
   
    % Generate binary mask
    mask = segmentation(left, right);
    
    % Render new frame
    frame_left = render(left(:, :, :, 2), mask, bg, render_mode);
    
    % Write the rendered frame into
    video_buffer(mod(frame_count, batch_size) + 1, :, :, :) = frame_left;
    
    % Write batches into the video file
    if mod(frame_count + 1, batch_size) == 0
        video_file.video(frame_count - batch_size + 2 : frame_count + 1, :, :, :) = video_buffer;
    end
    
    frame_count = frame_count + 1;
end


% Write the remaining frames to the file
remaining_frames = mod(frame_count, batch_size);
if remaining_frames ~= 0
    video_file.video(frame_count + 1 : frame_count + remaining_frames, :, :, :) = video_buffer(1 : remaining_frames, :, :, :);
end
    


%% Stop timer here
elapsed_time = toc


%% Write Movie to Disk
if store
    video_writer = VideoWriter('testvideo.avi');
    open(video_writer);
   
    for i = 1 : frame_count - mod(frame_count, batch_size) % loop through batches of frames
        if mod(i, batch_size) == 1
            % read a batch from the .mat file and write it to the video
            video_buffer = uint8(video_file.video(i : i + batch_size - 1, :, :, :));
            
            for f = 1 : batch_size
                writeVideo(video_writer, squeeze(video_buffer(f, :, :, :))); %write the image to file
            end
        end     
    end
    
    %store remaining frames
    remaining_frames = mod(frame_count, batch_size);
    if remaining_frames ~= 0
        video_buffer = uint8(video_file.video(end - remaining_frames + 1 : end, :, :, :));
   
        for f = 1 : remaining_frames
            writeVideo(video_writer, squeeze(video_buffer(f, :, :, :))); %write the image to file
        end
    end
    
    close(video_writer);
end
