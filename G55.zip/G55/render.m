function [result] = render(frame,mask,bg,render_mode)
    result = frame;
    % Only show Foreground
    if render_mode == "foreground"
        result(~mask) = 0;
    % Only show Background
    elseif render_mode == "background"
        result(mask) = 0;
    % Higlight fore- and background in different colors
    elseif render_mode == "overlay"
        blue = mask;
        blue(:, :, 2:3) = [];
        red = ~mask;
        red(:, :, 1:2) = [];
        result(blue) = 1;
        result(red) = 190;
    % Insert a virtual (video) background
    elseif render_mode == "substitute" 
        if isa(bg, 'VideoReader')
            if ~bg.hasFrame()
                bg.currentTime = 0;
            end
            bg = bg.readFrame();
        end
        result = imresize(bg, [600, 800]);
        result(mask) = frame(mask);
    end
end
