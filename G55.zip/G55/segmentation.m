function [mask] = segmentation(left, right)
    %% Allocate memory
    left_gray = zeros(size(left, 1), size(left, 2), size(left, 4));
    left_sub = zeros(size(left, 1), size(left, 2), size(left, 4)-1);
    left_edge = zeros(size(left_gray));
    left_edge_sub = zeros(size(left_sub));
    mask = zeros(size(left_edge_sub));

    %% Subtract two following frames
    for i = 1:size(left_gray, 3)
        % Convert rgb to grayscale
        left_gray(:, :, i) = rgb2gray(left(:, :, :, i));
        % Gaussian filtering
        left_gray(:, :, i) = imgaussfilt(left_gray(:, :, i));
    end
    for i = 1:size(left_gray, 3) - 1
        % Get difference between frames
        tmp = left_gray(:, :, i) - left_gray(:, :, i+1);
        % Remove noise
        tmp(tmp < 15) = 0;
        left_sub(:, :, i) = bwmorph(tmp, 'majority');
    end

    %% Detect edges
    for i = 1:size(left_edge, 3)
        left_edge(:, :, i) = edge(left_gray(:, :, i));
    end

    %% Combine edge-subtraction and frame-subtraction
    for i = 1:size(left_edge_sub, 3)
        tmp = left_edge(:, :, i) - left_edge(:, :, i+1);
        tmp = bwmorph(tmp, 'bridge');
        tmp = logical(left_sub(:, :, i) + tmp);
        left_edge_sub(:, :, i) = bwareaopen(tmp, 40);
    end

    %% Create mask (clustering and boundary)
    for i = 1:size(left_edge_sub, 3)
        if sum(left_edge_sub(:, :, i) ~= 0, 'all') > 2
            % Clustering
            [~, mask_1, mask_2] = blob_centers(left_edge_sub(:, :, i), 70);
            % Boundary around pixel cluster (shape)
            mask(:, :, i) = logical(bound(mask_1, 0.4) + bound(mask_2, 0.4));  
        else
            mask(:, :, i) = bound(left_edge_sub(:, :, i), 0.4);
        end
    end
    
    %% Majority voting
    mask = sum(mask, 3);
    mask(mask<2) = 0;
    mask = imfill(mask, 'holes');
    mask = logical(mask);

    %% Reshape mask for a rgb image
    mask = [mask(1:600, 1:800) mask(1:600, 1:800) mask(1:600, 1:800)];
    mask = reshape(mask, 600, 800, 3);
end
