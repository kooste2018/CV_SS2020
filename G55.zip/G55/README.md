

<!-- PROJECT LOGO -->
<br />
<p align="center">
    <img src="./GUI/source/tum-logo.png" alt="Logo" width="80" height="80">
  </a>

  <h3 align="center">Computer Vision Challenge</h3>

<p align="center">




<!-- TABLE OF CONTENTS -->
## Table of Contents

* [Graphische Benuteroberfläche](#Graphische_Benutzeroberfläche)
* [challenge.m](#challenge.m)
* [Virtueller (Video) Hintergrund](#Virtueller_(Video)_Hintergrund)
* [Kontakt](#Kontakt)
* [Erwähnenswerte Matlab Methoden](#Erwähnenswerte_Matlab_Methoden)



<!-- ABOUT THE PROJECT -->
## Graphische Benutzeroberfläche
In der GUI können alle notwendigen Eingaben getätigt werden. Während des Abspielens im normalen oder loop Modus werden automatisch die gerenderten frames in einer Datei zwischengespeichert.
Wird nun mit dem Save Button ein Speicherort + Dateiname ausgewählt wird daraus eine Video-Datei erzeugt.
Der virtuelle Hintergrund, egal ob Bild oder Video, kann während der Wiedergabe geändert werden. Auch der Render-Modus kann verändert werden ohne das Abspielen zu beenden.
Wird jedoch einer der Parameter `scene`, `start`, `right_input` oder `left_input` verändert, wird die Wiedergabe beendet und muss neu gestartet werden.

<!-- GETTING STARTED -->
## challenge.m

Zusätzlich zur GUI gibt es natürlich auch das Matlab Skript `challenge.m`.
Dieses kann wie gewohnt in der Matlab Konsole gestartet werden.
Alle notwendigen Einstellungen sind in der `config.m` zu finden. 

### Virtueller (Video) Hintergrund
Unser Software unterstützt sowohl ein virtuelles Hintergrundbild, als auch ein Hintergrundvideo. Hierzu kann in der GUI der Pfad zu einer Bilddatei (`.jpg, .png`) oder einer Videodatei (`.mp4, .avi`) angegeben werden. 
In der `config.m` bitte die passenden Zeilen ein-/auskommentieren:
```Python
% Load Virtual Background
bg = imread("Pfad\zu\Bild\Datei");

% Load Virtual Background video
video_file = 'Pfad\zu\Video\Datei';
bg = VideoReader(video_file);
```

<!-- CONTACT -->
## Kontakt

Matthias Emde - ga63suz@tum.de

Andreas Lösel - ga63miy@tum.de


<!-- ACKNOWLEDGEMENTS -->
## Erwähnenswerte Matlab Methoden
* [boundary](https://de.mathworks.com/help/matlab/ref/boundary.html)
* [rgb2gray](https://de.mathworks.com/help/matlab/ref/rgb2gray.html)
* [imgaussfilt](https://de.mathworks.com/help/images/ref/imgaussfilt.html)
* [bwmorph](https://de.mathworks.com/help/images/ref/bwmorph.html)
* [bwareaopen](https://de.mathworks.com/help/images/ref/bwareaopen.html)
* [imfill](https://de.mathworks.com/help/images/ref/imfill.html)
* [edge](https://de.mathworks.com/help/images/ref/edge.html)



