classdef ImageReader < handle
    properties
        src = []     % Path to scene folder
        L = []       % Index of left-view camera
        R = []       % Index of right-view camera
        start = 1    % Index of start frame
        N = 4        % Batch size
        loop = 0     % Loop completion flag
        step = 1     % Step size of loaded images (how many to skip)
        frame_id_L   % List of images in left-view scene folder
        frame_id_R   % List of images in right-view scene folder
        first = true % First iteration flag
        left         % Left-view stream
        right        % Right-view stream
    end
    
    methods
        % Constructor
        function obj = ImageReader(src, L, R, start, N, step)
            % Path to scene folder, converting '\' to '/'
            obj.src = strrep(src, '\', '/');           
            % Left view camera {1, 2}
            obj.L = L;
            % Path to left camera frames
            path_L = strcat(obj.src, '_C', int2str(obj.L), '/');
            % List of left camera frames
            obj.frame_id_L = dir(strcat(path_L, '*.jpg'));
            % Right view camera {2, 3}
            obj.R = R;
            % Path to right camera frames
            path_R = strcat(obj.src, '_C', int2str(obj.R), '/');
            % List of right camera frames
            obj.frame_id_R = dir(strcat(path_R, '*.jpg'));
            % Framenumber to start
            if nargin > 3
                obj.start = start;
            end
            % Amount of consecutive pictures to load 
            if nargin > 4
                obj.N = N;
            end
            % How many images to skip
            if nargin > 5
                obj.step = step;
            end
            % Loop completion flag
            obj.loop = 0;
            % Check values
            assert(obj.N >= 4, ...
                'Four frames are required for the segmentation algorithm to work.');
            assert(obj.L == 1 | obj.L == 2, ...
                'Please use Camera 1 or Camera 2 for the left view.');
            assert(obj.R == 2 | obj.R == 3, ...
                'Please use Camera 2 or Camera 3 for the right view.');
            assert(obj.L ~= obj.R, ...
                'Please use different Cameras for the left and right view.');
            assert(obj.start > 0, "Invalid start value.");
        end
              
        % Reads in the next images while already loaded images are kept in
        % memory
        function [left, right, loop] = next(obj)
            % First iteration
            if obj.first
                % Allocate memory
                obj.left = zeros(600, 800, 3, obj.N, 'uint8');
                obj.right = zeros(600, 800, 3, obj.N, 'uint8');
                % Load N consecutive frames
                for i = 1 : obj.N
                    path_L = strcat(obj.frame_id_L(obj.start + i).folder, ...
                        '\', obj.frame_id_L(obj.start + i).name);
                    path_R = strcat(obj.frame_id_R(obj.start + i).folder, ...
                        '\', obj.frame_id_R(obj.start + i).name);
                    obj.left(:, :, :, i) = imread(path_L);
                    obj.right(:, :, :, i) = imread(path_R);
                end
                obj.first = false;
            % Not the first iteration
            else
                % Rotate frames in the storage
                obj.left = circshift(obj.left, -obj.step, 4);
                obj.right = circshift(obj.right, -obj.step, 4);
                % Only load the next step pictures
                for i = obj.N - obj.step + 1 : obj.N
                    % If all images read, set loop completion flag
                    if i > size(obj.frame_id_L, 1)
                        obj.loop = 1;
                        obj.start = 0;
                        break
                    end
                    path_L = strcat(obj.frame_id_L(obj.start + i).folder, ...
                        '\', obj.frame_id_L(obj.start + i).name);
                    path_R = strcat(obj.frame_id_R(obj.start + i).folder, ...
                        '\', obj.frame_id_R(obj.start + i).name);
                    obj.left(:, :, :, i) = imread(path_L);
                    obj.right(:, :, :, i) = imread(path_R);             
                end
            end
            obj.start = obj.start + obj.step;
            loop = obj.loop;
            left = obj.left;
            right = obj.right;
        end
    end
end
