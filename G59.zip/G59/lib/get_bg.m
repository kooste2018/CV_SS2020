function bg = get_bg(left)
num_frame = size(left,3)/3;
bg_l =  zeros(600,800,3);

for i = 1:num_frame
    bg_l = bg_l + double(left(:,:,3*(i-1)+1:3*i));
end
bg = bg_l/num_frame;
end