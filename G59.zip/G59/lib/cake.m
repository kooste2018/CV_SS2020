function Cake = cake(min_dist)
    % The cake function creates a "cake matrix" that contains a circular set-up of zeros
    % and fills the rest of the matrix with ones. 
    % This function can be used to eliminate all potential features around a stronger feature
    % that don't meet the minimal distance to this respective feature.
%     Cake = zeros(min_dist*2 + 1,min_dist*2 + 1)
%     Cake(min_dist+1,min_dist+1) = 1;

    imageSizeX = min_dist*2 + 1;
    imageSizeY = min_dist*2 + 1;
    [columnsInImage rowsInImage] = meshgrid(1:imageSizeX, 1:imageSizeY);
    % create the circle in the image.
    centerX = min_dist+1;
    centerY = min_dist+1;
    radius = min_dist;
    Cake = (rowsInImage - centerY).^2+ (columnsInImage - centerX).^2 <= radius.^2;
%     class(Cake)
    Cake = ~Cake;
%     Cake(min_dist+1,min_dist+1) = 1;
end
