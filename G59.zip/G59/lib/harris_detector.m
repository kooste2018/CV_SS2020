function features = harris_detector(input_image, varargin)
    % In this function you are going to implement a Harris detector that extracts features
    % from the input_image.
    
    % Input parser from task 1.7
    % segment_length    size of the image segment
    % k                 weighting between corner- and edge-priority
    % tau               threshold value for detection of a corner
    % do_plot           image display variable
    % min_dist          minimal distance of two features in pixels
    % tile_size         size of the tiles
    % N                 maximal number of features per tile
    defaultSegment = 15;
    defaultK = 0.05;
    defaultTau = 10^6;
    defaultPlot = false;
    defaultMin_dist = 20;
    defaultTile_size = [200 200];
    defaultN = 5;

    p = inputParser;
    validScalarPosNum1 = @(x) isnumeric(x)  && (x > 1) && mod(x,2) == 1;
    validScalarPosNum2 = @(x) isnumeric(x)  && (x >= 0) && (x <= 1);
    validScalarPosNum3 = @(x) isnumeric(x)  && (x >0);
    validScalarPosNum4 = @(x) islogical(x);
    validScalarPosNum5 = @(x) isnumeric(x)  && (x >= 1);
    validScalarPosNum6 = @(x) isnumeric(x) ;
    validScalarPosNum7 = @(x) isnumeric(x)  && (x >= 1);
    
    addRequired(p,'input_image');
    addOptional(p,'Segment_length',defaultSegment,validScalarPosNum1);
    addOptional(p,'k',defaultK,validScalarPosNum2);
    addOptional(p,'tau',defaultTau,validScalarPosNum3);
    addOptional(p,'do_plot',defaultPlot,validScalarPosNum4);
    addOptional(p,'min_dist',defaultMin_dist,validScalarPosNum5);
    addOptional(p,'tile_size',defaultTile_size,validScalarPosNum6);
    addOptional(p,'N',defaultN,validScalarPosNum7);
    addOptional(p,'sub_mask',ones(size(input_image)),@(x) size(x,1) >= 0);
    
    
    parse(p,input_image,varargin{:});

    segment_length = p.Results.Segment_length;
    k = p.Results.k;
    tau = p.Results.tau;
    do_plot = p.Results.do_plot;
    min_dist = p.Results.min_dist;
    sub_mask = p.Results.sub_mask;
    
    tile_size = p.Results.tile_size;
    if isscalar(tile_size)
        tile_size = [tile_size tile_size];
    end
    N = p.Results.N;
    % Preparation for feature extraction from task 1.4
    % Ix, Iy            image gradient in x- and y-direction
    % w                 weighting vector
    % G11, G12, G22     entries of the Harris matrix
        
    
    % Preparation for feature extraction
    % Check if it is a grayscale image
    if size(input_image,3) ~= 1
        msg = 'Image format has to be NxMx1';
        error(msg)
    end
    
    % Approximation of the image gradient
    img_double = double(input_image);
    [Ix Iy] = sobel_xy(img_double);
    % Weighting
    
    % 2 Separable Filter ergeben das 2D Filter
    sigma = segment_length/size(input_image,1)*1000;%change with the length of segment
    %     W = fspecial('gaussian')
    half_segment = (segment_length-1)/2;  
    xx = -half_segment:half_segment;
    Gauss = 1/(2*pi*sigma)*exp(-(xx.^2)/(2*sigma^2));   
    w = Gauss;    
    w = w./sum(w);  

    
    % Harris Matrix G
    G11 = Ix.^2;
    G12 = Ix.*Iy;
    G21 = G12;
    G22 = Iy.^2;
    
    G11 = conv2(G11,w,"same");
    G11 = conv2(G11,w',"same");
    G12 = conv2(G12,w,"same");
    G12 = conv2(G12,w',"same");
    G21 = G12;
    G22 = conv2(G22,w,"same");
    G22 = conv2(G22,w',"same");
    
    % Feature extraction with the Harris measurement from task 1.5
    % corners           matrix containing the value of the Harris measurement for each pixel               
    H = abs(G11.*G22 - G12.*G12 - k*(G11 + G22).^2);
    
%     figure;
%     surf(H)
%     

%     if do_plot       
%         figure
%         surf(H)
%         title('harris H value')
%     end    
    
    H = H./max(H,[],'all');
    corners = H.*double(H>tau).*sub_mask;
    %normalize the corners


    if do_plot       
        figure
        surf(corners)
        title('harris corner value(after tau)')
    end    
    
    
    
    [row, col] = find(corners ~= 0);
    features = [col' ; row'];
    
   if do_plot       
        figure
        imshow(uint8(input_image)) 
        hold on;
        plot(features(1,:),features(2,:),'r+','MarkerSize',5)
        hold off;
        title('harris sub_optimizied versionn');
   end
   
  
   
   %----------------------------------------------------------------------
   
    % Feature preparation from task 1.9
    % sorted_index      sorted indices of features in decreasing order of feature strength
    %add zero border
    new_corners = zeros(size(corners)+2*[min_dist min_dist]);
    new_corners(min_dist+1:min_dist+size(corners,1),min_dist+1:min_dist+size(corners,2)) = corners;
    
     corner_1D = new_corners(:);
     number_nonzero = sum((corner_1D ~= 0));
%      corner_1D = corner_1D(1:number_nonzero);
    
    [~,sorted_index] = sort(corner_1D,'descend');
    sorted_index = sorted_index(1:number_nonzero);
    
    corners = new_corners;
    
    % Accumulator array from task 1.10
    % acc_array         accumulator array which counts the features per tile
    % features          empty array for storing the final features
    xx = ceil(size(input_image,1)/tile_size(1));
    yy = ceil(size(input_image,2)/tile_size(2));
    acc_array = zeros(xx,yy);
    features = zeros(2,min(N*xx*yy,size(sorted_index,1)));
    
    
    
    % Feature detection with minimal distance and maximal number of features per tile
    

    expand_sz = max(tile_size(1),tile_size(2));
    corners_expanded = zeros(size(corners,1) + 2*expand_sz - 2*min_dist,size(corners,2) + 2*expand_sz - 2*min_dist);

    original_corners = corners(min_dist + 1:min_dist + size(input_image,1),min_dist + 1:min_dist + size(input_image,2));
    corners_expanded(expand_sz + 1:size(input_image,1)+expand_sz,expand_sz + 1:size(input_image,2)+expand_sz)...
        = original_corners;
    
    xx = ceil(size(input_image,1)/tile_size(1));
    yy = ceil(size(input_image,2)/tile_size(2));

    height = tile_size(1);
    width = tile_size(2);    
    
    total_feature = 0;
    for i = 1:xx
        for j = 1:yy
            count_feature = 0; %find all adequents
            
            while 1               
                tile_working_on = corners_expanded((i-1)*height + 1 + expand_sz: i*height + expand_sz,...
                (j-1)*width + 1 + expand_sz:j*width + expand_sz);%locate the tile we are working on
            
                %if no find, break
                if sum(sum(tile_working_on~=0)) == 0
                    acc_array(i,j) = count_feature;
                    break
                end
                [x y] = find(tile_working_on == max(max(tile_working_on))); %return row and col %Reference Frame: tile_working_on
                
                
                %Get the coordinate of first one
                x = x(1); y = y(1);
                
                %Transform Coordinate %Reference Frame: Expanded_Corners
                x = x + (i-1)*height + expand_sz;
                y = y + (j-1)*width + expand_sz;
                %[x y] = [x y] + [(i-1)*height + expand_sz,(j-1)*width + expand_sz]

                %expand the cake mask, make it around the pixel we just discovered
                CAKE = ones(size(corners_expanded));
%                 size(CAKE)
%                 size(cake(min_dist))
%                 size(CAKE(x - min_dist:x + min_dist,y - min_dist:y + min_dist))
                CAKE(x - min_dist:x + min_dist,y - min_dist:y + min_dist) = cake(min_dist);
                
                %change corners_expanded(get rid of those less important pixels)
%                 size(corners_expanded)
%                 size(CAKE)
                corners_expanded = corners_expanded.*CAKE;
                
                %iterate
                count_feature = count_feature + 1;
                total_feature = total_feature + 1;
                
                %Reference Frame, Original Input_Image!
                features(1,total_feature) = x - expand_sz;
                features(2,total_feature) = y - expand_sz;
                
                %if enough, break
                if count_feature == N
                    acc_array(i,j) = count_feature;
                    break
                end
                
            end
        end
    end
    
    
        %Confusion about X Y axis
        features = features(:,1:total_feature);
        feature(1,:) = features(2,:);
        feature(2,:) = features(1,:);
        features = feature;
        %Plot
        %img boundary
        
        
        if do_plot       
            figure
            imshow(uint8(input_image)) 
            hold on;
            plot(features(1,:),features(2,:),'r.','MarkerSize',20)
        end    
    
end

function [Fx, Fy] = sobel_xy(input_image)
    % In this function you have to implement a Sobel filter 
    % that calculates the image gradient in x- and y- direction of a grayscale image.

    
    input_img_double = double(input_image);
    input_img_extended = zeros(size(input_img_double,1)+2,size(input_img_double,2)+2);
    input_img_extended(2:end-1,2:end-1) = input_img_double;

    Sobel_hori = [ 1 0 -1; 2 0 -2;1 0 -1];
    Sobel_verti = Sobel_hori';

    Fx = zeros(size(input_img_double,1),size(input_img_double,2));
    Fy = zeros(size(input_img_double,1),size(input_img_double,2));
% 
%     for x = 1:size(input_img_double,1)
%         for y = 1:size(input_img_double,2)
% 
%             Fx(x,y) = sum(sum(input_img_extended(x:x+2,y:y+2).*Sobel_hori))*(1/8)*log(2);
%             Fy(x,y) = sum(sum(input_img_extended(x:x+2,y:y+2).*Sobel_verti))*(1/8)*log(2);
% 
%         end 
%     end
    Fx = conv2(input_img_double,Sobel_hori,'same');
    Fy = conv2(input_img_double,Sobel_verti,'same');
    
%     Fx = abs(Fx)
%     Fy = abs(Fy)
        
end
