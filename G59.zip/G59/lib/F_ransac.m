function [correspondences_robust, largest_set_F] = F_ransac(correspondences, varargin)
    % This function implements the RANSAC algorithm to determine 
    % robust corresponding image points

    %Default Value
    default_epsilon = 0.5;
    default_p = 0.5;
    default_tolerance = 0.01;
    
    %initiate inputParser
    S = inputParser;
    validScalarPosNum1 = @(x) isnumeric(x)  && (x >= 0) && (x <= 1);
    validScalarPosNum2 = @(x) isnumeric(x)  && (x >= 0) && (x <= 1);
    validScalarPosNum3 = @(x) isnumeric(x)  && (x > 0);

    addRequired(S,'correspondences');
    addOptional(S,'epsilon',default_epsilon,validScalarPosNum1);
    addOptional(S,'p',default_p,validScalarPosNum2);
    addOptional(S,'tolerance',default_tolerance,validScalarPosNum3);

    parse(S,correspondences,varargin{:});

    epsilon = S.Results.epsilon;
    p = S.Results.p;
    tolerance = S.Results.tolerance;
    
    x1_pixel = [correspondences(1:2,:);ones(1,size(correspondences,2))];
    x2_pixel = [correspondences(3:4,:);ones(1,size(correspondences,2))];
    
    k = 8;
    s = log(1 - p)/log(1 - (1 - epsilon)^k);
    largest_set_size = 0;
    largest_set_dist = inf;
    largest_set_F = zeros(3,3);

    i = 0;
    while i <= s
        number_cor = size(correspondences,2);
        selected = randperm(number_cor,k);%random permutation
        [F] = eight_point(correspondences(:,selected));
        sampson_distance_all = sampson_dist(F,x1_pixel,x2_pixel);
        remaining_index_all = nonzeros((sampson_distance_all < tolerance).*(1:number_cor));
        largest_set_size_new = length(remaining_index_all);
        largest_set_dist_new = sum(sampson_distance_all(remaining_index_all));
        if largest_set_size_new > largest_set_size
            largest_set_size = largest_set_size_new;
            largest_set_F = F;
            correspondences_robust = correspondences(:,selected);
        elseif largest_set_size_new == largest_set_size
            if largest_set_dist_new < largest_set_dist
                largest_set_size = largest_set_size_new;
                largest_set_F = F;
                correspondences_robust = correspondences(:,selected);
            end
        end
        i = i + 1;
    end
    

end

function sd = sampson_dist(F, x1_pixel, x2_pixel)
    % This function calculates the Sampson distance based on the fundamental matrix F
    
    size(F)
    size(x1_pixel)
    e = [0 0 1];
    e=[0 -e(3) e(2) ; e(3) 0 -e(1) ; -e(2) e(1) 0 ];
%     sd = sum(x2_pixel.'.*F.*x1_pixel).^2./(sum(e.*F.*x1_pixel).^2 + sum(x2_pixel.'.*F.*e).^2)
    sd = sum(x2_pixel.*(F*x1_pixel)).^2 ./ (sum((e*F*x1_pixel).^2) + sum((e*F'*x2_pixel).^2));
%     sd = (x2_pixel)/()

end