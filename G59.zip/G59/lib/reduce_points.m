function features = reduce_points(corners)
    
    tile_size = [2 2];
    min_dist = 1;
    N =4;

    
    input_image = zeros(size(corners));
% Feature preparation from task 1.9
    % sorted_index      sorted indices of features in decreasing order of feature strength
    %add zero border
    new_corners = zeros(size(corners)+2*[min_dist min_dist]);
    new_corners(min_dist+1:min_dist+size(corners,1),min_dist+1:min_dist+size(corners,2)) = corners;
    
     corner_1D = new_corners(:);
     number_nonzero = sum((corner_1D ~= 0));
%      corner_1D = corner_1D(1:number_nonzero);
    
    [~,sorted_index] = sort(corner_1D,'descend');
    sorted_index = sorted_index(1:number_nonzero);
    
    corners = new_corners;
    
    % Accumulator array from task 1.10
    % acc_array         accumulator array which counts the features per tile
    % features          empty array for storing the final features
    xx = ceil(size(input_image,1)/tile_size(1));
    yy = ceil(size(input_image,2)/tile_size(2));
    acc_array = zeros(xx,yy);
    features = zeros(2,min(N*xx*yy,size(sorted_index,1)));
    
    
    
    % Feature detection with minimal distance and maximal number of features per tile
    

    expand_sz = max(tile_size(1),tile_size(2));
    corners_expanded = zeros(size(corners,1) + 2*expand_sz - 2*min_dist,size(corners,2) + 2*expand_sz - 2*min_dist);

    original_corners = corners(min_dist + 1:min_dist + size(input_image,1),min_dist + 1:min_dist + size(input_image,2));
    corners_expanded(expand_sz + 1:size(input_image,1)+expand_sz,expand_sz + 1:size(input_image,2)+expand_sz)...
        = original_corners;
    
    xx = ceil(size(input_image,1)/tile_size(1));
    yy = ceil(size(input_image,2)/tile_size(2));

    height = tile_size(1);
    width = tile_size(2);    
    
    total_feature = 0;
    for i = 1:xx
        for j = 1:yy
            count_feature = 0; %find all adequents
            
            while 1               
                tile_working_on = corners_expanded((i-1)*height + 1 + expand_sz: i*height + expand_sz,...
                (j-1)*width + 1 + expand_sz:j*width + expand_sz);%locate the tile we are working on
            
                %if no find, break
                if sum(sum(tile_working_on~=0)) == 0
                    acc_array(i,j) = count_feature;
                    break
                end
                [x y] = find(tile_working_on == max(max(tile_working_on))); %return row and col %Reference Frame: tile_working_on
               
                
                %Get the coordinate of first one
                x = x(1); y = y(1);
                
                %Transform Coordinate %Reference Frame: Expanded_Corners
                x = x + (i-1)*height + expand_sz;
                y = y + (j-1)*width + expand_sz;
                %[x y] = [x y] + [(i-1)*height + expand_sz,(j-1)*width + expand_sz]

                %expand the cake mask, make it around the pixel we just discovered
                CAKE = ones(size(corners_expanded));
                CAKE(x - min_dist:x + min_dist,y - min_dist:y + min_dist) = cake(min_dist);
                
                %change corners_expanded(get rid of those less important pixels)
                corners_expanded = corners_expanded.*CAKE;
                
                %iterate
                count_feature = count_feature + 1;
                total_feature = total_feature + 1;
                
                %Reference Frame, Original Input_Image!
                features(1,total_feature) = x - expand_sz;
                features(2,total_feature) = y - expand_sz;
                
                %if enough, break
                if count_feature == N
                    acc_array(i,j) = count_feature;
                    break
                end
                
            end
        end
    end
    
    
        %Confusion about X Y axis
        features = features(:,1:total_feature);
        feature(1,:) = features(2,:);
        feature(2,:) = features(1,:);
        features = feature;
        %Plot
        %img boundary
      
end