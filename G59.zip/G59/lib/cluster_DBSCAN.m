function [data_set_labelled] = cluster_DBSCAN(data_set,factor,varargin)
%Description
%Use DBSCAN to remove outliers

defaultPlot = false;
defaulteps = 60;
defaultminPts = 4;

p = inputParser;

addRequired(p,'data_set');
addRequired(p,'resize_factor');
addOptional(p,'eps',defaulteps,@(x) isnumeric(x));
addOptional(p,'minPts',defaultminPts,@(x) isnumeric(x));
addOptional(p,'do_plot',defaultPlot,@(x) islogical(x));


parse(p,data_set,factor,varargin{:});

data_set = p.Results.data_set;
resize_factor = p.Results.resize_factor;
eps = p.Results.eps;
minPts = p.Results.minPts;
do_plot = p.Results.do_plot;



original_data_set = data_set;
%Start Algorithm
num_data = size(data_set,2);
%add label to 3rd row, 4th row the index
%-1 undefined, 0 noise, other cluster number
data_set = [data_set;-ones(1,num_data);1:num_data];
C = 0; %cluster number

for i = 1:num_data
    %determine the neighbors
    if data_set(3,i) ~= -1 %ignore this point if labelled
        continue 
    end
    N = RangeQuery(data_set,data_set(:,i),eps);
    if size(N,2) < minPts
        data_set(3,i) = 0;%0 refers to noise
        continue
    end
    C = C + 1;
    data_set(3,i) = C;% the initial point
    Seed_set = N; %cropped version of data_set
    index_P = N(4,:) == i;
    Seed_set(:,index_P) = [];%remove the P 
    Num_seed = size(Seed_set,2);
    Num_processed = 0;
    while Num_processed < Num_seed
        if Seed_set(3,Num_processed+1) == 0
            data_set(3,Seed_set(4,Num_processed+1)) = C;%both _set need change
            Seed_set(3,Num_processed+1) = C;
        end
        if Seed_set(3,Num_processed+1) ~= -1
            Num_processed = Num_processed + 1;
            Num_seed = size(Seed_set,2);
           continue 
        end
        data_set(3,Seed_set(4,Num_processed+1)) = C;
        Seed_set(3,Num_processed+1) = C;
        
        N = RangeQuery(data_set,Seed_set(:,Num_processed+1),eps);
        if size(N,2) >= minPts
            %eliminate all the repeating parts
            logical_mat = zeros(1,size(N,2));%which should remain
            for k = 1:size(N,2)
                comp = sum(N(:,k) == Seed_set);
                if isempty(find(comp == 4,1))
                    logical_mat(k) = k;
                end
            end
            N = N(:,nonzeros(logical_mat));
            Seed_set = [Seed_set,N];
        end
        Num_processed = Num_processed + 1;
        Num_seed = size(Seed_set,2);
    end
end
data_set_labelled = data_set;

warning('off','all')
if do_plot
label_and_index = data_set_labelled;
remain_feature = original_data_set*resize_factor;
noise_feature = remain_feature(:,label_and_index(3,:) == 0);
cluster1_feature = remain_feature(:,label_and_index(3,:) == 1);
cluster2_feature = remain_feature(:,label_and_index(3,:) == 2);
cluster3_feature = remain_feature(:,label_and_index(3,:) == 3);
cluster4_feature = remain_feature(:,label_and_index(3,:) == 4);
cluster5_feature = remain_feature(:,label_and_index(3,:) == 5);
figure
imshow(uint8(zeros(600,800))) ;
hold on;
plot(noise_feature(1,:),noise_feature(2,:),'b.','MarkerSize',10)
plot(cluster1_feature(1,:),cluster1_feature(2,:),'ro','MarkerSize',5)
plot(cluster2_feature(1,:),cluster2_feature(2,:),'go','MarkerSize',5)
plot(cluster3_feature(1,:),cluster3_feature(2,:),'co','MarkerSize',5)
plot(cluster4_feature(1,:),cluster4_feature(2,:),'mo','MarkerSize',5)
plot(cluster5_feature(1,:),cluster5_feature(2,:),'yo','MarkerSize',5)
title('DBscan Plot');
if size(noise_feature,2) == 0
    legend('cluster1','cluster2','cluster3','cluster4','cluster5')
else
    legend('noise','cluster1','cluster2','cluster3','cluster4','cluster5')
end  
hold off;
end
warning('on')
end

function N = RangeQuery(data_set,Q,eps)
%Q the researched point, N for neighbours
    num_data = size(data_set,2);
    N = [];
    for i = 1:num_data
        if distFunc(data_set(1:2,i),Q) <= eps
            N = [N data_set(:,i)];
        end
    end
end

function dist = distFunc(P,Q)
    dist = sqrt(sum((P(1:2) - Q(1:2)).^2));
end