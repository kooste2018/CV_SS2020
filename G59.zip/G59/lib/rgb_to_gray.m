function gray_image = rgb_to_gray(input_image)
    % This function is supposed to convert a RGB-image to a grayscale image.
    % If the image is already a grayscale image directly return it.
    if size(input_image,3) == 1
        gray_image = input_image;
        return
    end
    input_image = double(input_image);
    gray_image = 0.299*input_image(:,:,1) + 0.587*input_image(:,:,2) + 0.114*input_image(:,:,3);
end