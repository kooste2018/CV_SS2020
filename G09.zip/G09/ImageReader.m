classdef ImageReader < handle
    % src:   path of the folder of the scene
    % L:     to choose which one as the left camera, its value could only be {1,2}
    % R:     to choose which one as the right camera, its value could only be {2,3}
    % start: to determin which frame(JPG) to start with
    % N:     how many frames to load/read after the current frame
    properties
        src char
        L {mustBeMember(L,[1,2])}
        R {mustBeMember(R,[2,3])}
        start   % Remark: if "start" is not given, set start to 0
        N       % Remark: if "N" is not given, set N to 1
        filepathL % File path of left camera
        filepathR % File path of right camera
        Total_JPGs % The name list of frames
        Totalnum_JPGs % Total number of JPGs in the folder
    end
    
    methods
        function ir = ImageReader(src,L,R,varargin)
            p = inputParser;
            
            defaultStart = 0;
            validStart = @(x) ((isnumeric(x)) && (x == round(x)) && (x>=0));
            
            defaultN = 1;
            validN = @(x) ((isnumeric(x)) && (x == round(x)) && (x>0));
            
            addOptional(p,'start',defaultStart,validStart);
            addOptional(p,'N',defaultN,validN);
            
            parse(p,varargin{:});
            ir.src = src;
            ir.L = L;
            ir.R = R;
            ir.start = p.Results.start;
            ir.N = p.Results.N;
            
            % Set the filepath
            ir.filepathL = fullfile(ir.src, [ir.src(end-5:end) '_C' num2str(ir.L)]); 
            ir.filepathR = fullfile(ir.src, [ir.src(end-5:end) '_C' num2str(ir.R)]); 
            
            % Get the name list of frames
            ir.Total_JPGs = dir(fullfile(ir.filepathL, '*.jpg'));
            if isempty(ir.Total_JPGs) 
                error('no frame in the selected scene'); 
            end
            % Get total number of JPGs in the folder
            ir.Totalnum_JPGs = length(ir.Total_JPGs);
        end        
        
        function [left,right,loop] = next(ir)
            
            
            left_acc = [];     % Tensor of frames recorded by left camera
            right_acc = [];    % Tensor of frames recorded by right camera
            
            % Index of start JPG
            ir.start = ir.start + 1;
            startid = ir.start;
            
            % if enough JPGs left
            if startid + ir.N < ir.Totalnum_JPGs

                for i = startid : startid + ir.N 
                    imnameL = fullfile(ir.filepathL,ir.Total_JPGs(i).name);
                    imnameR = fullfile(ir.filepathR,ir.Total_JPGs(i).name);
                    left_acc = cat(3, left_acc, imread(imnameL));
                    right_acc= cat(3, right_acc,imread(imnameR));
                end
                loop = 0;
                
            % if not enough JPGs left, set "loop" to 1
            else
                for i = startid : ir.Totalnum_JPGs
                    imnameL = fullfile(ir.filepathL,ir.Total_JPGs(i).name);
                    imnameR = fullfile(ir.filepathR,ir.Total_JPGs(i).name);
                    left_acc = cat(3, left_acc, imread(imnameL));
                    right_acc= cat(3, right_acc,imread(imnameR));
                end
                loop = 1;                
                ir.start = 0;
            end
            left = left_acc;
            right = right_acc;
        end
    end
    
end
