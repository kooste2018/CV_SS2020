%% Computer Vision Challenge 2020 config.m

%% Generall Settings
% Group number:
group_number = 09;

% Group members:
members = {'Xin Su','Xinyang Li','Zhangyi Chen','Yinxian Li','Jiang Long'};

% Email-Address (from Moodle!):
mail = {'ge35qov@mytum.de','xinyang.li@tum.de','ge82pot@mytum.de','ge37ziq@mytum.de','ge37zoc@mytum.de'};


%% Setup Image Reader
% Specify Scene Folder
src = 'd:\Users\DELL\Desktop\CV\Challenge\ChokePoint\P3L_S6'; % !!!Change it to your own path!!!

% Select Cameras
L = 1;
R = 2;

% Choose a start point
% start = randi(1000);
start = 0;

% Choose the number of succseeding frames
N = 4;

ir = ImageReader(src, L, R, start, N);    
% ir = ImageReader(src, L, R, start); % N takes the default value
% ir = ImageReader(src, L, R);        % start and N take default values
% ir = ImageReader(src, L, R, 'N',N); % start takes the default value


%% Output Settings
% Output Path
dest = 'output.avi';

% Load Virual Background
src_bg = fullfile('VirtualBackground','test.jpg');
bg = imread(src_bg);

% Select rendering mode
render_mode = 'foreground';

% Store Output?
store = true;

% Load Virual Background Video (Bonus task)
bgv = fullfile('VirtualBackground','test.mp4');
global obj;
global num_bgFrames;
global bgframe_index;
if strcmp(render_mode,'substitute_video')
    obj = VideoReader(bgv);
    num_bgFrames = obj.NumFrames;
    bgframe_index = 1;
end

