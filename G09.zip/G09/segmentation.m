function [mask] = segmentation(left,right)
% Add function description here
% 1. This function creates the mask of the middle frame from input tensors.
% 2. Description of basic idea and algorithm: 
%    The basic Idea in the segementation is to divide the timely moving and static
%    parts of the images.Firtly, the the function would ceate a mask (Mask_Pre)
%    for preprocessing the images, in order to filter out the main part of 
%    background and eliminate the influence of noises.Then, 4 masks are created 
%    independently with different methods. In the end, we have merged all the 4 masks
%    and created the final mask as output with help of voting. 
% 3. Method 1: Deviation. We check the pixel-wise Deviation in the frames 
%              and estimate the foregound/background.
%
% 4. Method 2: Sorting. We check the pixels in the middle frames with the other
%              frames.  If the gray value of the pixel is sorted as
%              'outlier', then this pixel is foregound.
%
% 5. Method 3: Subtracion between frames: compare the the Subtraction of 
%              adjacent frames with a threshold, then we could estimate the
%              foregoud. 
%
% 6. Method 4: Extract the Feature points of the difference between the adjacent 
%              frames. In this way we obtain an accurate edge of the
%              foreground.
%
% 7. Merge and Vote: Because all the masks are not perfect. We have merged
%               all the masks from method 1 to 4. 

%% Some parameters:
% Paramters for morpohp operation: imclose, imopen, imdilare and imerode.
SE_30 = strel('disk', 30);
SE_50 = strel('disk', 50);
SE_20 = strel('disk', 20);
gray_level_threshold = 10; % the threshold between background and foreground.
[high,width,depth] = size(left);
frame_number = depth/3;
middle_frame = ceil(frame_number/2);


%% Convert the tensor 'left' from RGB to Gray-Images.
Gray_tensor = zeros(high,width,frame_number);
left = histeq(left,256);% enhance the contrast of the input tensor. 
for i = 1:frame_number
    Gray_tensor(:,:,i) = 0.30 * left(:,:,3*i-2)+ 0.59 *left(:,:,3*i-1)+ 0.11 * left(:,:,3*i);
    Gray_tensor(:,:,i) = imgaussfilt(Gray_tensor(:,:,i)); % gauss filter.
end


%% Preprocessing the images with help of Mask_Pre. 
% The Mask_Pre is produced  with help of the pixel-wise deviation.
% In the Preprocessing we cut a rough region with person out. 
% So we can elimate the major part of background noise. 
Gray_max = max(Gray_tensor,[],3);
Gray_min = min(Gray_tensor,[],3);
diff = Gray_max - Gray_min; % diff: pixel-wise deviation in the frames.

% compare with threshold and estimate the foreground
diff = diff > gray_level_threshold * 2.5;
diff = bwareaopen(diff,30);
% initialize the Gray-tensor, and preprocess the images.
Gray_tensor_Processed = Gray_tensor;
Mask_Pre = imdilate(diff,SE_50);
Mask_Pre = bwconvhull(Mask_Pre,'objects');
Mask_Pre = bwareafilt(Mask_Pre,[3000,600*800]); % filter out the noises.

for i = 1 : size(Gray_tensor_Processed,3)
    Gray_tensor_Processed(:,:,i) = Gray_tensor(:,:,i) .* Mask_Pre;
end


%% The method with Deviation. 
Mask_Deviation = diff;
Mask_Deviation = imclose(Mask_Deviation,SE_30);
Mask_Deviation = imfill(Mask_Deviation,'hole');
% diff = boundarymask(diff); 


%% Pixelweise sorting in N+1 Frames . 
% Get the middle frame as a tensor, inorder to simplify the calculation.
Tensor_Frame = zeros(high,width,frame_number); 
for i = 1 : frame_number
    Tensor_Frame(:,:,i) = Gray_tensor_Processed(:,:,middle_frame);
end
number_threshold = floor(frame_number/2); % treshold of sort number.
% now caculate the difference.
diff_sort = abs(Tensor_Frame - Gray_tensor_Processed); 
% compare with gray_level_treshold and determin outlier.
Mask_sort = diff_sort >= gray_level_threshold;

% If the Pixel is classifined as 'outlier', then it is foreground
Mask_sort = sum(Mask_sort,3);
Mask_sort = Mask_sort >  number_threshold;
Mask_sort = bwareaopen(Mask_sort,30);
Mask_sort = imclose(Mask_sort,SE_30);
Mask_sort = imfill(Mask_sort,'hole');


%%   Subtracion between adjacent frames   
if frame_number > 2
    Diff_Frame = abs(Gray_tensor_Processed(:,:,middle_frame)- Gray_tensor_Processed(:,:,middle_frame-1));
    Mask_Sub = Diff_Frame> gray_level_threshold;
else
    Mask_Sub = abs(Gray_tensor_Processed(:,:,end) - Gray_tensor_Processed(:,:,1));
end
    Mask_Sub = bwareaopen(Mask_Sub,30); 
    Mask_Sub = imclose(Mask_Sub,SE_50);
    Mask_Sub = imfill(Mask_Sub,'hole');

    
%% Feature detect and edge subtraction , this method obtains accurate edge information 
if frame_number > 2
   Mask_Fea_Sub1 = edge(Diff_Frame,'sobel');
   Diff_Frame2 = abs(Gray_tensor_Processed(:,:,middle_frame+1) - Gray_tensor_Processed(:,:,middle_frame));
   Mask_Fea_Sub2= edge(Diff_Frame2,'sobel');
   Mask_Fea_Sub = Mask_Fea_Sub1 | Mask_Fea_Sub2;
   Mask_Fea_Sub = bwareaopen(Mask_Fea_Sub,30);%process the mask
   Mask_Fea_Sub = imclose(Mask_Fea_Sub,SE_50);
   Mask_Fea_Sub = imfill(Mask_Fea_Sub,'hole');
else 
   Mask_Fea_Sub =  edge(abs(Gray_tensor_Processed(:,:,end) - Gray_tensor_Processed(:,:,1)),'canny');
   Mask_Fea_Sub = bwareaopen(Mask_Fea_Sub,30);%process the mask
   Mask_Fea_Sub = imclose(Mask_Fea_Sub,SE_50);
   Mask_Fea_Sub = imfill(Mask_Fea_Sub,'hole');
end


%% Merge and Voting 
Mask_merge = Mask_Deviation + Mask_sort + Mask_Sub + Mask_Fea_Sub; 
Mask_merge = Mask_merge >=2;%%% a threshold.
Mask_merge(end,:) =1;
Mask_merge(:,end) =1;
Mask_merge = imfill(Mask_merge,'hole');
Mask_merge = imopen(Mask_merge,SE_20);
Mask_merge = bwareafilt(Mask_merge,[5000,600*800]);% filter out noise, again.
mask = Mask_merge;
end

