NOTE!!

    Before running this program, please check whether your folder structure of dataset ChokePoint is set correctly. It has the structure
    ChokePoint -> P**_S* -> P**_S*_C* -> *.jpg
    Especially for the files P2*_S*, whose original structure should be changed accordingly.
    The right structure can be found in the pdf of Challenge introduction as well as Thema "checking extracted folder scenes" 
    in moodle forum Allgemeines Forum.
    
    Before running, Change the variable "src" to your own scene path!

Two Ways to run the entire program:

	Method 1:       Use "start_gui" in command window to call the GUI. Choose settings in GUI. Click "Start"-button.
                    	In this way, GUI will show the input and output frame while the program is running. 
                    	In the end it will display running time and output a video, if it's required.

	*Note:          In each scene, the first hundred pictures are almost pure background. If you choose 0 as Start Point, 
                    	GUI will show pure background input and pure black output frames for about 1 minute. 
                   	So we suggest to start from the frame after those background images (set the variable start >100), 
                    	otherwise you have to just wait for 1 min.

	Method 2:       Check the parameter setting and definition in "config.m" (especially definition of ir and path of scene/output/background).
                    	Which settings you should complete before running the main function is described below (Description -> config.m).
                    	Then run the "challenge.m".
                    	In the end it will display running time and output a video, if it's required. 
                    	You can find the output video named 'output.avi' in the folder.
                    	the running time is long. Please be patient and wait until the program is over....

Introduction

	This project aims on the estimation and separation of foreground and background from a small sequence of a video.

	It contains the following files:
	ImageReader.m				— a class of reading frames
	segmentation.m				— a function estimate and segment fore- and background from actual frame
	render.m				— a function to subtract or replace background
	config.m				— set the related parameters
	challenge.m                 		— main function
    	test.jpg                    		- image to substitute background
    	test.mp4                    		- video to substitute background

Requirement

	MatLab 2020a
	Image Processing Toolbox

Description

	ImageReader.m
	The class ImageReader is defined, which desires the following input parameters:
	src: 		character string, path of the folder of the scene
 	L:          to choose which one as the left camera, its value could only be 1 or 2
	R:          to choose which one as the right camera, its value could only be 2 or 3
	start:      nonnegative integer, to determine which frame(JPG) to start with, not necessary, default value: 0
	N:          positive integer, how many frames to load/read after the current frame, not necessary, default value: 1
	The method next() return two frames tensors of number N+1 of left and right cameras and a value loop that is 0 if there are 
	still enough remaining frames in the video sequence and 1 in contrast, the tensors begins from current frame indexed by parameter start+1,
    	which means for example if start = 100, it takes frames from the 101th frame in video sequence.
	Once calling method next() the property start of this object increases by 1 and the related tensors and value will be returned. 
	If there is no enough remaining frames, next() will return loop as 1 and the rest of frames then reset start to 0 
	

	segmentation.m	
	This function takes left and right tensors to return a binary image mask of the middle frame in left tensor, where in the background 
	mask takes value 0 and foreground 1. The mask has the same dimension with the actual frame to be segmented，which is 600*800*1.
	
	The mask in segmentation belongs to the middle frame in tensor, which means if we have five Images, the mask belongs to the third image.
	The best results in our Experiment is under the condition N = 4, which means 5 Frames in tensor.
	

	
	render.m
	The input of this function is frame, mask, bg, mode. It can produce different outputs according to different input modes.
	'foreground':       The background is set to black. The foreground in the picture should be as little as possible to be changed.
	'background':       The foreground is set to black and only the background is visible.
	'overlay':          foreground and background are fine distinguishable colors colored transparent.
  	'substitute':       Replace the background with a virtual background image.
   	'substitute_video': Replace the background with a virtual background video. (The image and video path need to be given in config.m, for example, 'd/G09/VirtualBackground/test.mp4')

	
	config.m
	The following parameters and definition should be set before run the main function:
	src, L, R, start, N:        desired parameters to define the ImageReader object, start and N are not necessary.
	A object ir of class ImageReader is defined in four forms:
    	ir = ImageReader(src, L, R, start, N);  % the values of start and N are given
    	ir = ImageReader(src, L, R, start);     % N takes the default value
    	ir = ImageReader(src, L, R);            % start and N take default values
    	ir = ImageReader(src, L, R, 'N',N);     % start takes the default value
	dest:                        the avi file which saves the resulting video after rendering
	src_bg:                      the path of virtual background image
	render_mode:                 the mode of handling the background, takes 1 of 5 forms introduced above
    	bgv:                         the path of virtual background video
	store:                       true or false, determines whether the resulting video is stored in dest or not

	challenge.m
	Main function to run after the config.m is appropriately set.
    	After running, the settings in config.m will be load and then enter into loop.
    	During every loop, ir.next(), segmentation, render and writeVideo (if required) will be called once.
    	In the end, the output video writing is finished (if required) and the elapsed time is displayed in minutes.
