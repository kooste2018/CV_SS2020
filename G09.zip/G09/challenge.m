%% Computer Vision Challenge 2020 challenge.m
clear
clc
%% Start timer here
tic
config;

%% Generate Movie
if store
    v = VideoWriter(dest,'Motion JPEG AVI');
    open(v)
end

loop = 0;
while loop ~= 1
    
    % Get next image tensors
    [left,right,loop] = ir.next();
    
    % Generate binary mask
    mask = segmentation(left,right);

    current_frame_num = ceil(size(left,3)/3/2);
    frame = left(:,:,3*current_frame_num-2:3*current_frame_num);
    % Render new frame
    result = render(frame,mask,bg,render_mode);
    
    %% Write Movie to Disk
    if store
        writeVideo(v,result);
    end
end

if store
    close(v)
end

%% Stop timer here
elapsed_time = toc;
disp(['Running time:' num2str(elapsed_time/60) 'mins'])
