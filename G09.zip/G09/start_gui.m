function varargout = start_gui(varargin)
% START_GUI MATLAB code for start_gui.fig
%      START_GUI, by itself, creates a new START_GUI or raises the existing
%      singleton*.
%
%      H = START_GUI returns the handle to a new START_GUI or the handle to
%      the existing singleton*.
%
%      START_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in START_GUI.M with the given input arguments.
%
%      START_GUI('Property','Value',...) creates a new START_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before start_gui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to start_gui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help start_gui

% Last Modified by GUIDE v2.5 09-Jul-2020 07:37:28

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @start_gui_OpeningFcn, ...
                   'gui_OutputFcn',  @start_gui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before start_gui is made visible.
function start_gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to start_gui (see VARARGIN)

% Choose default command line output for start_gui
handles.output = hObject;

config;
set(handles.edit_src,'String',src);
set(handles.edit_src_bg,'String',src_bg);
if ~exist('start','var')
    set(handles.edit_start,'String','0');
else
    set(handles.edit_start,'String',start);
end
set(handles.edit_src_movie,'String',dest);
set(handles.edit_bg_v,'String',bgv);


% Update handles structure
guidata(hObject, handles);

% UIWAIT makes start_gui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = start_gui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function edit_src_Callback(hObject, eventdata, handles)
% hObject    handle to edit_src (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_src as text
%        str2double(get(hObject,'String')) returns contents of edit_src as a double
handles.edit_src = get(hObject,'String');


% --- Executes during object creation, after setting all properties.
function edit_src_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_src (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_src_bg_Callback(hObject, eventdata, handles)
% hObject    handle to edit_src_bg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_src_bg as text
%        str2double(get(hObject,'String')) returns contents of edit_src_bg as a double
handles.edit_src_bg = get(hObject,'String');


% --- Executes during object creation, after setting all properties.
function edit_src_bg_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_src_bg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_start_Callback(hObject, eventdata, handles)
% hObject    handle to edit_start (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_start as text
%        str2double(get(hObject,'String')) returns contents of edit_start as a double
handles.edit_start = get(hObject,'Value');


% --- Executes during object creation, after setting all properties.
function edit_start_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_start (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_mode_Callback(hObject, eventdata, handles)
% hObject    handle to edit_mode (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_mode as text
%        str2double(get(hObject,'String')) returns contents of edit_mode as a double
handles.edit_mode = get(hObject,'String');



% --- Executes during object creation, after setting all properties.
function edit_mode_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_mode (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% --- Executes on button press in pushbutton_start.
function pushbutton_start_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_start (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global Stop_is_pressed
Stop_is_pressed = 0;
global obj;
global num_bgFrames;
global bgframe_index;

set(handles.txt_play,'string','(Playing)');
set(handles.txt_stop,'string','(Click to stop video)');
set(handles.txt_loop,'string','(Click to play in loop)');

config;

% Get the setting from user
src = get(handles.edit_src,'String');
src_bg = get(handles.edit_src_bg,'String');
start = str2double(get(handles.edit_start,'String'));
popupmenu_mode_contents = cellstr(get(handles.popupmenu_mode,'String'));
render_mode = popupmenu_mode_contents{get(handles.popupmenu_mode,'Value')};
dest = get(handles.edit_src_movie,'String');
if exist('start','var') && exist('N','var')
    ir = ImageReader(src, L, R, start, N);
elseif exist('start','var') && ~exist('N','var')
    ir = ImageReader(src, L, R, start);
elseif ~exist('start','var') && exist('N','var')
    ir = ImageReader(src, L, R, 'N', N);
elseif ~exist('start','var') && ~exist('N','var')
    ir = ImageReader(src, L, R);
end
bg = imread(src_bg);

if strcmp(render_mode,'substitute_video')
    obj = VideoReader(get(handles.edit_bg_v,'String'));
    num_bgFrames = obj.NumFrames;
    bgframe_index = 1;
end

if store
    v = VideoWriter(dest,'Motion JPEG AVI');
    open(v)
end

% Start timer
tic
loop = 0;
while loop ~= 1
    if Stop_is_pressed
            break
    end
    % Get next image tensors
    [left,right,loop] = ir.next();
    % Generate binary mask
    mask = segmentation(left,right);
    
    current_frame_num = ceil(size(left,3)/3/2);
    frame = left(:,:,3*current_frame_num-2:3*current_frame_num);
    % Render new frame
    result = render(frame,mask,bg,render_mode);
    % Show input frame in axes 1
    axes(handles.axes_input);
    imshow(frame);
    % Show output frame in axes 2
    axes(handles.axes_output);
    imshow(result);
    pause(1/30);
    % Output the video
    if store
        writeVideo(v,result);
    end    
end
elapsed_time = toc;
% Display running time
if ~Stop_is_pressed
    set(handles.txt_run,'string',['Running time: ' num2str(elapsed_time/60) 'mins']);
    if store
        close(v)
    end
    set(handles.txt_play,'string','(Click to play video)');
    set(handles.txt_stop,'string','(Stopped)');
    set(handles.txt_loop,'string','(Click to play in loop)');
end


% --- Executes on button press in pushbutton_stop.
function pushbutton_stop_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_stop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global Stop_is_pressed
Stop_is_pressed = 1;

set(handles.txt_play,'string','(Click to play video)');
set(handles.txt_stop,'string','(Stopped)');
set(handles.txt_loop,'string','(Click to play in loop)');


% --- Executes on button press in pushbutton_loop.
function pushbutton_loop_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_loop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global Stop_is_pressed
Stop_is_pressed = 0;
global obj;
global num_bgFrames;
global bgframe_index;

set(handles.txt_play,'string','(Click to play video)');
set(handles.txt_stop,'string','(Click to stop video)');
set(handles.txt_loop,'string','(Playing in loop)');
set(handles.txt_run,'string','');

config;

% Play in loop
while ~Stop_is_pressed    
    src = get(handles.edit_src,'String');
    src_bg = get(handles.edit_src_bg,'String');
    start = str2double(get(handles.edit_start,'String'));
    popupmenu_mode_contents = cellstr(get(handles.popupmenu_mode,'String'));
    render_mode = popupmenu_mode_contents{get(handles.popupmenu_mode,'Value')};
    dest = get(handles.edit_src_movie,'String');
    if exist('start','var') && exist('N','var')
        ir = ImageReader(src, L, R, start, N);
    elseif exist('start','var') && ~exist('N','var')
        ir = ImageReader(src, L, R, start);
    elseif ~exist('start','var') && exist('N','var')
        ir = ImageReader(src, L, R, 'N', N);
    elseif ~exist('start','var') && ~exist('N','var')
        ir = ImageReader(src, L, R);
    end
    bg = imread(src_bg);
    
    if strcmp(render_mode,'substitute_video')
        obj = VideoReader(get(handles.edit_bg_v,'String'));
        num_bgFrames = obj.NumFrames;
        bgframe_index = 1;
    end
    
    loop = 0;
    while loop ~= 1
        if Stop_is_pressed
            break
        end
        % Get next image tensors
        [left,right,loop] = ir.next();
        % Generate binary mask
        mask = segmentation(left,right);
        
        current_frame_num = ceil(size(left,3)/3/2);
        frame = left(:,:,3*current_frame_num-2:3*current_frame_num);
        % Render new frame
        result = render(frame,mask,bg,render_mode);
        % Show input frame in axes 1
        axes(handles.axes_input);
        imshow(frame);
        % Show output frame in axes 2
        axes(handles.axes_output);
        imshow(result);
        pause(1/30);
    end
end



% --- Executes on button press in pushbutton_browse1.
function pushbutton_browse1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_browse1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
path_src = uigetdir({},'Choose the path of scene');
if isnumeric(path_src)
    config;
    set(handles.edit_src,'String',src);
else
    set(handles.edit_src,'string',path_src);
end



% --- Executes on button press in pushbutton_browse2.
function pushbutton_browse2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_browse2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[bg_name,bg_path] = uigetfile({'*.*',  'All Files (*.*)'},'Choose the virtual background image');
if isnumeric(bg_name) && isnumeric(bg_path)
    config;
    set(handles.edit_src_bg,'String',src_bg);
else
    set(handles.edit_src_bg,'string',[bg_path bg_name]);
end



function edit_src_movie_Callback(hObject, eventdata, handles)
% hObject    handle to edit_src_movie (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_src_movie as text
%        str2double(get(hObject,'String')) returns contents of edit_src_movie as a double
handles.edit_src_movie = get(hObject,'String');

% --- Executes during object creation, after setting all properties.
function edit_src_movie_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_src_movie (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton_browse3.
function pushbutton_browse3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_browse3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
path_movie = uigetdir({},'Choose the path for the output movie');
if isnumeric(path_movie)
    config;
    set(handles.edit_src_movie,'String',dest);
else
    set(handles.edit_src_movie,'string',path_movie);
end


% --- Executes on selection change in popupmenu_mode.
function popupmenu_mode_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu_mode (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu_mode contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu_mode


% --- Executes during object creation, after setting all properties.
function popupmenu_mode_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu_mode (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function axes_input_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes_input (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes_input


% --- Executes during object creation, after setting all properties.
function axes_output_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes_output (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes_output


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure

global Stop_is_pressed
% Stop before closing
if ~Stop_is_pressed
    Stop_is_pressed = 1;
end

delete(hObject);



function edit_bg_v_Callback(hObject, eventdata, handles)
% hObject    handle to edit_bg_v (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_bg_v as text
%        str2double(get(hObject,'String')) returns contents of edit_bg_v as a double
handles.edit_bg_v = get(hObject,'String');


% --- Executes during object creation, after setting all properties.
function edit_bg_v_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_bg_v (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton_browse4.
function pushbutton_browse4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_browse4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[bg_v_name,bg_v_path] = uigetfile({'*.*',  'All Files (*.*)'},'Choose the virtual background video');
if isnumeric(bg_v_name) && isnumeric(bg_v_path)
    config;
    set(handles.edit_bg_v,'String',bgv);
else
    set(handles.edit_bg_v,'string',[bg_v_path bg_v_name]);
end
