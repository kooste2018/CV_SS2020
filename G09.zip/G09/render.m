function [result] = render(frame,mask,bg,mode)
% frame:  current frame of left camera (size 600x800x3)
% mask:   binary mask of current frame (size 600x800)
% bg:     virtual background with size AxBx3.
% mode:   choose between different modes
% result: output frame (size 600x800x3)
global obj;
global num_bgFrames;
global bgframe_index;
mask_inverse = ~mask;

switch mode
    case 'foreground'
        
        result = im2double(frame) .* mask;
        
    case 'background'
        
        result = im2double(frame) .* mask_inverse;
        
    case 'overlay'
        
        result = imoverlay(frame,mask,'r') + imoverlay(frame,mask_inverse,'b');
        
    case 'substitute'
        bg = imresize(bg,[600,800]);
        
        result = im2double(frame) .* mask + im2double(bg) .* mask_inverse;
        
    case 'substitute_video'
        
        bg_v = imresize(read(obj,bgframe_index),[600 800]);
        result = im2double(frame) .* mask + im2double(bg_v) .* mask_inverse;
        bgframe_index = bgframe_index + 1;
        if bgframe_index == num_bgFrames
            bgframe_index = 1;
        end
        
end
end

