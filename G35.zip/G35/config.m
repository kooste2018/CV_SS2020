%% Computer Vision Challenge 2020 config.m


%% Generall Settings
% Group number:
group_number = 35;

% Group members:
members = {'Jiangnan Huang', 'Zhiwei Liang','Nan Chen', 'Ivan Hartono'};

% Email-Address (from Moodle!):
mail = {'jiangnan.huang@tum.de', 'zhiwei.liang@tum.de','n.chen@tum.de','ivan.hartono@tum.de'};

%% Setup Image Reader
% Specify Scene Folder
if ispc %if it's windows
    src = strcat(pwd,'\another folder\ChokePoint\P1L_S1');  % pwd: identify current folder
else
    if ismac||isunix %if it's mac or unix
        src = strcat(pwd,'/another folder/ChokePoint/data/P1L_S1');
    else
        error("System not supported!\n");
    end
end

% Select Cameras
L =1; %set index of folder, camera left and right
R =2; 

% Choose a start point
start = 1500;

% Choose the number of succseeding frames
N =4; %set number of following images

%get object
ir = ImageReader(src, L, R, start, N); %initialize object of class ImageReader

%set loop 
loop=0;

%% Output Settings
% Output Path
%check system
if ispc %system recognition again for path 
    dest = strcat(pwd,'\output.avi');
else
    if ismac||isunix
        dest = strcat(pwd,'/output.avi');
    else
        error("System not supported!\n");
    end
end

% Load Virtual Background
if ispc %all virtual background will be saved in bg folder, which is in the same directory of this config.m
    bgpath = strcat(pwd,'\another folder\bg\bg2.jpg');
else
    if ismac||isunix
        bgpath = strcat(pwd,'/another folder/bg/bg2.jpg');
    else
        error("System not supported!\n");
    end
end

bg = im2double(imread(bgpath));

bg=imresize(bg,[600,800]); % adapt the bg to the size of 600*800*3, since the original virtual background can be of random size
        
% Select rendering mode
render_mode = "substitute";

% Create a movie array
movie=cell(1,5000);
movie_flag=0; %if movie is full, set flag 1

%index for movie, for loop later
i=1;

% Store Output?
store = true;
