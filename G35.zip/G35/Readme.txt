This readme is fitted to help user running the start_gui.

Initializing Data
Step 0			: Manually clear your workspace, type clear in Command Window
Step 1			: type start_gui at Command Window
Step 2			: Look at Choose Data Path button group
Step 3			: Choose main working folder, format for this is as follows if we use Abbildung 2 from Challenge pdf: "~/ChokePoint"
Step 4 (optional)	: choose portal, entrance method and scene. It is important to note, if portal is 1, there is no scene 5. If not chosen, by default will choose P1E_S1
Step 5			: Choose background image file, location can be anywhere, important is that format must be "*.jpg"
Step 6 (optional)	: Define Camera Left and Camera Right, see docu for more detail. If not chosen, by default Camera Left 1 Camera Right 2
Step 7 (optional)	: Define Starting Position, if not chosen, by default is 20
Step 8			: Look at Rendering Mode button group
Step 9 (optional)	: Choose rendering mode, if not chosen, by default is foreground
Step 10			: Look at Processing Mode button group
Step 11 (optional)	: to save, press start? checkbox and choose where to save from pressing Save Destination Folder (pressing order in step 11 is not important) 
Step 12 (optional)	: activate loop checkbox to start non-terminating loop for image processing. If not chosen, by default there is terminating loop
Starting Process
Step 13			: Press start button to start operation, look at top left, that is location of scene folder chosen, make sure it is same as what is needed
Step 14			: check status bar top middle, Choose Parameter should change into Starting Program signaling start button is pressed, 
			  then if loop is chosen, iteration number will be shown here, bottom middle show also loop status, 
			  in which it is going to be written "Loop in progress, press stop to end". To end the process, press stop
Step 15			: Top middle will show "Showing Video", bottom middle will show Loop ended, after video ends,top middle will show "Program is finished"
Step 16			: in bottom right check save status to see if data is saved successfully, bottom left shows how many seconds it takes to run the image processing

It is important to note, every single button determining location in pc has no default value, since every pc has different data location. 
All default value can be found at the end of chapter 7 of docu (Table 1) 
 
