%this function generates a binary mask for the provided images in left and
%right
function mask = segmentation(left, right)

%get the current and the following image from the left camera frame
im_current = im2double(rgb2gray(left(:,:,1:3)));
im_following = im2double(rgb2gray(left(:,:,4:6)));

%define hyperparameters that can be tuned for creation of the optimal mask
tau = 0.15;                 %specifies the allowed delta before pixel change is detected as movement
sigma = 2;                  %sigma value for Gau� filter to blur the image
epsilon = 0.3;              %specifies the threshold for when a pixel is true after Gau�-filtering
skipped_points = 20 ;       %amount of points that are skipped for boundary detection
box_plus = 25;              %bounding box is increased by this amount of pixels
h = fspecial('sobel');      % sobel filter kernel

%-----------------------------------------------------------------------------------------------------%

%define lower and upper threshold values of the following image
im_min = (1-tau)*(im_following);
im_max = (1+tau)*(im_following);

%make a movement mask that is 1 if pixel changed more than tau in the
%following image (else 0)
mask = ones(size(im_current));
mask( (im_max > im_current & im_current > im_min) ) = [0];

% Blur the mask with a Gau� filter and apply threshold to determine new
% binary mask, also fill all holes in the mask
mask = imgaussfilt(double(mask),sigma);
mask(mask > epsilon) = 1;
mask(mask <= epsilon) = 0;
mask = imfill(mask);

%Find bounding box of blobs of pixels that are true
hBlobAnalysis = vision.BlobAnalysis('MinimumBlobArea', 7000, 'MaximumBlobArea', 400000);
[objArea, objCeontroid, bboxOut] = step(hBlobAnalysis, logical(mask));

%connect overlapping bounding boxes to one bounding box
mask1 = zeros(size(mask));
for j = 1:size(bboxOut,1)
    mask1(bboxOut(j,2):(bboxOut(j,2)+ bboxOut(j,4))-1 , bboxOut(j,1):(bboxOut(j,1)+ bboxOut(j,3))-1 ) = 1;
end
[objArea, objCeontroid, bboxOut] = step(hBlobAnalysis, logical(mask1));


%allocate memory of final mask
mask_end = zeros(size(mask,1), size(mask,2), size(objArea,1));

%if blobs are detected, compute mask, otherwise return black mask
if objCeontroid ~= 0
    
    %loop over all detected blobs and make an individual mask
    for k = 1:size(objArea,1)
        
        %reset variables
        points = zeros(2,1);
        a=1;
        
        % perform sobel filtering of mask
        mask_end(:,:,k) = logical( imfilter(mask,h) + imfilter(mask,h') );
        
        
        % make bounding boxes bigger and limit that it doesn't go over the
        % image border
        i_vec = (bboxOut(k,2)-box_plus) : (bboxOut(k,2)+ bboxOut(k,4)+ box_plus);
        i_vec(i_vec > size(mask,1)) = size(mask,1);
        i_vec(i_vec < 1) = 1;
        
        j_vec = (bboxOut(k,1)-5*box_plus) : (bboxOut(k,1)+ bboxOut(k,3)+ box_plus);
        j_vec(j_vec > size(mask,2)) = size(mask,2);
        j_vec(j_vec < 1) = 1;
        
        %check each pixel of the bounding box, if true save it to variable
        %points
        for i = i_vec
            for j = j_vec
                if mask_end(i,j,k) ==1
                    if mod(a,skipped_points) == 0
                        points(1,a/skipped_points)=i;
                        points(2,a/skipped_points)=j;
                    end
                    a=a+1;
                end
            end
        end
        
        %format data
        x=points(1,:)';
        y=points(2,:)';
        
        %find an outer boundary of detected pixels and generate polygon
        shrink_factor = 0.5;
        bound = boundary(x, y, shrink_factor);
        
        %make a binary mask from the generated polygon boundary
        mask_end(:,:,k) = poly2mask(y(bound),x(bound),size(im_current,1),size(im_current,2));
    end
    %combine the masks of all detected bounding boxes and combine them
    mask = logical(sum(mask_end,3));
else
    %no bounding box detected: return black mask
    mask= zeros(size(mask1));
end

end