%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ORDNERSTRUKTUR:

Folgende Dateien müssen alle vorhanden sein!
- challenge.m
- config.m 
- ImageReader.m
- render.m
- segmentation.m
- start_gui.mlapp
- icons8-warning-48.png
- loop3.png
- Pause.png
- play.png
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GRAFISCHE BENUTZEROBERFLÄCHE:

Die grafische Benutzeroberfläche kann mit 'start_gui' im MATLAB Kommandofenster öffnen.
Wird dieser Befehl ausgeführt, werden alle Einstellungen von config.m Datei ausgelesen
und in der GUI angezeigt.

Wie ist die Benutzeroberfläche zu bedienen?

Beim Klicken auf den Button "Virtual Background", öffnet sich ein Fenster,
in dem man den Pfad auswählen kann, an dem die Datei für den Hintergrund gespeichert ist.
Diese Datei kann sowohl ein Bild als auch ein Video sein.

Wird Button "Scene folder path" gedrückt, dann öffnet sich das Fenster in dem man den Pfad,
des zu lesenden Szenenordner auswählen kann.

Im Fenster "Film storage path" gibt man den Ort an dem die fertige gerenderte Datei gespeichert
werden soll. Wichtig zu beachten ist, dass man in diesem Fenster auch noch einen Titel für das
Video eingeben muss. Der Titel muss mit .avi enden.

Im drop down Menü "Rendering mode" kann man zwischen den vier verschiedenen Modi wählen. 

Im Fenster "Start point" kann man auswählen ab welchem Frame, das Video erzeugt werden soll.

Mittels des Buttons "Start rendering" wird der render Vorgangh gestartet.

Für den Fall, dass eine Einstellung vom Benutzer nicht gesetzt wurde, ploppt eine Warnung auf.
Sollte der gewählte Startpunkt größer sein als die Anzahl von Bildern im Szenenordner, wird 
ebenfalls davor gewarnt.

In den beiden linken Fenstern wird jeweils, die von eine Kamera gefilmte Szene gezeigt. Im rechten 
Fenster ist das Ergebnis des render Vorgangs zu sehen. Beide Filme werden lokal abgespeichert:
Der gerenderte Film wird unter dem angegebenen Pfad abgelegt. Der Input wird im selbe Ordner 
gespeichert, wo sich start_gui befindet.

Mit den beiden Buttons Play und Loop können die Filme in der GUI abgespiet werden. Drückt man auf 
auf einen Button, wird der andere disabled und es erscheint ein Pause Icon auf dem Button. Wird der 
Film bis zum Ende gespielt ohne ihn zu pausieren setzt sich das Icon Pause zurück auf Play bzw. Loop.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

CHALLENGE

Wenn man challenge nicht in GUI ausführen will, geht man so vor:

In der config.m Datei die Pfade anpassen.

Die Datei config.m ausführen.

Die Datei challenge.m ausführen


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
