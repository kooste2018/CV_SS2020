%% Computer Vision Challenge 2020 challenge.m

%% Initialize timer and Video
t1 = clock;

loop = 0;

if store == true
      
      videoName = convertStringsToChars(dest); %Name des Videos
      videoInputleft = 'StereoInputLeft.avi';%Name des originalen Videos 
      videoInputreft = 'StereoInputRight.avi';
      fps = 30; %fps          
      
      if(exist('videoName','file'))
          delete videoName.avi
      end
      aviobjInputLeft = VideoWriter(videoInputleft);
      aviobjInputLeft.FrameRate = fps;
      
      aviobjInputRight = VideoWriter(videoInputreft);
      aviobjInputRight.FrameRate = fps;
      
      aviobj = VideoWriter(videoName); %Ein avi-Objekt erstellen 
      aviobj.FrameRate = fps;
      
      open(aviobj); %Anfangen, das Video zu erstellen     
      open(aviobjInputLeft);
      open(aviobjInputRight);
end
  
while loop ~= 1
  % Get next image tensors 
  [left, right, loop] = ir.next();
  
  % Go to next
  ir.Start = ir.Start + 1;
  
  frame = left(:,:,1:3);
  frameRight = right(:,:,1:3);
  % the original video frames
  writeVideo(aviobjInputLeft, frame);
  
  writeVideo(aviobjInputRight, frameRight);

  % Generate binary mask
  mask = segmentation(left, right);

  % Render new frame
  result = render(frame, mask, bg, render_mode);
  
  %% Write Video
  if store == 1      
      writeVideo(aviobj, result);
  end  
end

%%Close video stream
close(aviobj);
close(aviobjInputLeft);
close(aviobjInputRight);
%% Stop timer here
t2 = clock;

elapsed_time = etime(t2,t1); %Die Laufzeit des Programms
elapsed_time = datestr(seconds(elapsed_time),' MM:SS');
fprintf(strcat('Die Laufzeit des Programms in Min:Sek ist ',elapsed_time,'\n'));

