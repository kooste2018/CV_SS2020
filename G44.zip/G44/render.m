%this function generates the output image from the current frame, mask and
%specified mode
function result = render(frame, mask, bg, mode)
    %allocate memory for the mask
    mask_end = zeros(size(mask,1), size(mask,2), 3);
    mask_end(:,:,1) = mask;
    mask_end(:,:,2) = mask;
    mask_end(:,:,3) = mask;
    
    %choose mode and render image accordingly
    switch mode 
        case 'foreground'
            result = mask_end .* frame;
            
        case 'background'
            result = (~mask_end) .* frame;
            
        case 'overlay'
            %color foreground and background
            frame_new = frame;
            frame_new(:,:,1) = frame(:,:,1) ./2;
            frame_new(:,:,2) = frame(:,:,2) ./2;
            
            bg_new = frame;
            bg_new(:,:,2) = frame(:,:,2) ./2;
            bg_new(:,:,3) = frame(:,:,3) ./2;
            
            %combine foreground and background with the mask
            result = mask_end .* frame_new + (~mask_end) .* bg_new;
            
        case 'substitute'
            %resize the specified image and render it in background
            bg = imresize(bg, [size(frame,1) , size(frame,2)] );
            result = mask_end .* frame + (~mask_end) .* im2double(bg);
            
    end

end

