%% Generall Settings
% Group number: 
group_number = 44;

% Group members:
members = {'Bouazizi Amir', 'Oussama Skhiri', 'Manuel Fujs', 'Michael Pircher','Yichu Chen'};

% Email-Address (from Moodle!):
mail = {'ga86wul@mytum.de', 'ga83pic@mytum.de','manuel.fujs@mytum.de','michael.pircher@tum.de','Yichu.chen@tum.de'};


%% Setup Image Reader
% Specify Scene Folder - (app.data.scenedirfield.value)
src = "";

% Select Cameras
L = 1;
R = 3;

% Choose a start point - start point gui
% (app.data.startpoint.value)
start = 1;

% Choose the number of succseeding frames
N = 1;

ir = ImageReader('src',src, 'L', L, 'R', R, 'start', start, 'N', N);





%% Output Settings
% Output Path -gui  (app.data.ouputpath.value)
dest = "C:\Users\Manue\Google Drive\CV Challenge\output.avi";

% Load Virual Background -gui  
bg = imread("C:\Users\Manue\Google Drive\CV Challenge\lena.jpg");

% Select rendering mode - gui 
render_mode = "foreground";

% Store Output?
store = true;