classdef ImageReader
  % In dieser Class werden zwei Videostreams aus einem Szenenordner eingelesen
  % und die Bilder von jeder Kamera werden als Tensor left und right zurueck
  % gegeben.
  
  properties     
      Src
      l
      r
      Start
      n
  end
  
  methods 
      function ir = ImageReader(varargin)
          %In dieser Funktion werden die Parameters von Bilder definiert.
          
          P = inputParser; %Input Parser
          
          P.addOptional('src',@isstring); %Dateipfad
          P.addOptional('L',@(x)isnumeric(x) && (x==1 || x==2)); %linke Kamera
          P.addOptional('R',@(x)isnumeric(x) && (x==2 || x==3)); %rechte Kamera
          P.addOptional('start',0,@(x)isnumeric(x) && (x>=0));
          P.addOptional('N',1,@(x)isnumeric(x) && (x>=1));
          %Parameter start gibt an, ab welcher Framenummer die Szene abgespielt 
          %werden soll, und Parameter N gibt an, wie viele Nachfolgebilder
          %geladen werden sollen.
          
          P.parse(varargin{:});
          
          ir.Src = P.Results.src;
          ir.l = P.Results.L;
          ir.r = P.Results.R;
          ir.Start = P.Results.start;
          ir.n = P.Results.N;
          
      end
      
      function [left, right, loop] = next(input)
          %In dieser Funktion werden die Frames der linken und rechten
          %Kamera als Tensor left un right zurueckgebeben.
          
          if input.l == input.r
              error('Sie muessen 2 unterschiedliche Kameras waehlen');
              %Linke Kamera und rechte Kamera sollen nicht die selbe
              %Kamera sein.
              
          else
              
              if input.l == 1
                  str_l = '_C1';
              else
                  str_l = '_C2';
              end
              
              if input.r == 2
                  str_r = '_C2';
              else
                  str_r = '_C3';
              end
              imgSubFolderArray = split(input.Src,["/","\"]);
              imgSubFolder = imgSubFolderArray(length(imgSubFolderArray));
              
              imgFolder_l = strcat(imgSubFolder,str_l);
              imgPath_l = strcat(input.Src,strcat("/",imgFolder_l));
              %Dateipfad von der linken Kamera
              
              imgFolder_r = strcat(imgSubFolder,str_r);
              imgPath_r = strcat(input.Src,strcat("/",imgFolder_r));
              %Dateipfad von der rechten Kamera

              imgDir_l = dir(strcat(imgPath_l, '/*.jpg'));
              imgDir_r = dir(strcat(imgPath_r, '/*.jpg'));
              %Informationen von den JPG-Datein im Pfad
              
              summe = length(imgDir_l);
          
              loop = 0;
              %Parameter loop unterscheidet sich, ob noch genuegend Bilder zur
              %Verfuegung stehen.
          
              for i = 1 : input.n + 1
                  
                  if loop > 0
                      break
                  end
                      
                  j = input.Start + i - 1;
                  
                  if i == 1
                      left = imread(strcat(imgPath_l, strcat("/", imgDir_l(j).name)));
                      right = imread(strcat(imgPath_r, strcat("/", imgDir_r(j).name)));
                  else
                      img_l = imread(strcat(imgPath_l, strcat("/", imgDir_l(j).name)));
                      img_r = imread(strcat(imgPath_r, strcat("/", imgDir_r(j).name)));
                      left = cat(3,left,img_l);
                      right = cat(3,right,img_r);
                      left = im2double(left);
                      right = im2double(right);
                      %Tensoren left und right.
                  end

                  if (input.Start + i + 1) > summe
                      loop = 1;
                      %Nicht genuegend Bilder, dann wird loop 1 gesetzt.
                  end
              end
          end
      end
  end
end
